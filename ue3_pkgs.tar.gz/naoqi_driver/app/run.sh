touch .catkin
source setup.bash
exec bin/naoqi_driver_node &>> naoqi_driver_node.log
