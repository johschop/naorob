^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package naoqi_apps
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.5.5 (2016-09-19)
------------------
* set Surya as the maintainer
* Contributors: Vincent Rabaud

0.5.4 (2016-05-20)
------------------

0.5.3 (2015-08-26)
------------------

0.5.2 (2015-08-11)
------------------

0.5.1 (2015-07-31)
------------------
* generate changelog
* generate changelog
* cleanup meta package.xml
* Contributors: Karsten Knese

* generate changelog
* cleanup meta package.xml
* Contributors: Karsten Knese

* cleanup meta package.xml
* Contributors: Karsten Knese

0.5.0 (2015-07-30)
------------------

0.4.8 (2015-06-25)
------------------

0.4.7 (2015-03-30)
------------------

0.4.6 (2015-02-27)
------------------
* update wiki ros links
* update repo links in package.xml
* Contributors: Mikael Arguedas

0.4.5 (2015-02-11)
------------------
* add naoqi_apps
* Contributors: Vincent Rabaud

* add naoqi_apps
* Contributors: Vincent Rabaud

0.4.4 (2015-01-16)
------------------

0.4.3 (2014-12-14)
------------------

0.4.2 (2014-11-26)
------------------

0.4.1 (2014-11-13)
------------------

0.4.0 (2014-11-06)
------------------
