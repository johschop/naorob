^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package nao_robot
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.5.15 (2016-11-23)
-------------------

0.5.14 (2016-01-23)
-------------------

0.5.13 (2016-01-16)
-------------------

0.5.12 (2016-01-01)
-------------------

0.5.11 (2015-08-11)
-------------------

0.5.10 (2015-07-31)
-------------------
* remove nao_pose
* Contributors: Karsten Knese

0.5.9 (2015-07-30)
------------------

0.5.8 (2015-07-30)
------------------

0.5.7 (2015-03-27)
------------------

0.5.6 (2015-02-27)
------------------

0.5.5 (2015-02-17)
------------------

0.5.4 (2015-02-17)
------------------

0.5.3 (2014-12-14)
------------------

0.5.2 (2014-12-04)
------------------

0.5.1 (2014-11-13)
------------------

0.5.0 (2014-11-06)
------------------
* transfer nao_robot
* 0.4.1
* update changelogs
* get the accent right in Séverin's name
* 0.4.0
* update changelogs
* 0.3.0
* update changelogs
* update maintainers
  Armin, thank you for all your work, in ROS, Octomap and NAO.
  Good luck out of the university !
* "0.2.3"
* Changelogs
* {ahornung->ros-nao}
* {ahornung->ros-nao}
* Update nao_robot package.xml
* "0.2.2"
* changelog
* "0.2.1"
* Changelogs
* "0.2.0"
* Adding (edited) catkin-generated changelogs
* Adding bugtracker and repo URLs to package manifests
* Fix nao_robot metapackage xml
* Add run_depends to nao_robot metapackage
* Initial catkinization.
  Beware! Compilation of nao_sensors_cpp has been temporarily disabled.
* Contributors: Armin Hornung, Karsten Knese, Miguel Sarabia, Séverin Lemaignan, Vincent Rabaud
