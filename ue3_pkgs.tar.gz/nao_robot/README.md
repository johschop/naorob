nao_robot
=========

ROS stack for the NAO robot, see http://www.ros.org/wiki/nao_robot
