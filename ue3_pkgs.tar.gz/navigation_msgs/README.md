# Navigation Messages

This repository contains messages used by the
[navigation stack](https://github.com/ros-planning/navigation).
It is intended for use in ROS Jade and above. Prior to Jade some of these
messages existed in the navigation repository.