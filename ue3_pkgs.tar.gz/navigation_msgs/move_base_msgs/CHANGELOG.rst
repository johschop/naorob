^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package move_base_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.13.0 (2015-03-16)
-------------------
* initial release from new repository
* Contributors: Michael Ferguson
