humanoid_msgs
=============

Messages and services for humanoid robots in ROS
